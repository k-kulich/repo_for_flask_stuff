from flask import Flask, url_for

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route('/carousel')
def carousel():
    img1 = url_for('static', filename='img/mars-1.jpg')
    img2 = url_for('static', filename='img/mars-2.jpg')
    img3 = url_for('static', filename='img/mars-3.jpg')
    return f'''
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
    crossorigin="anonymous">
    <title>Пейзажи Марса</title>
</head>
<body>
    <h1 style="text-align: center">Пейзажи Марса</h1>
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img class="d-block w-100" src="{img1}" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="{img2}" alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="{img3}" alt="Third slide">
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
      </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
    '''


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
