import datetime

from flask import Flask, render_template, url_for
from data.db_session import create_session, global_init
from data.users import User
from data.jobs import Jobs
from data.departments import Department

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def add_crew():
    cap = User()
    cap.name = 'Ridley'
    cap.surname = 'Scott'
    cap.age = 21
    cap.position = 'captain'
    cap.speciality = 'research engineer'
    cap.address = 'module_1'
    cap.email = 'scott_chief@mars.org'
    crew = [['Addams', 'Wednesday', 19, 'first pilot', 'shuttle pilot', 'module_2',
             'addams_w@mars.org'],
            ['Chang', 'Shon', 25, 'scientist', 'exobiologist', 'module_3', 'chang_bio@mars.org'],
            ['Walker', 'Karen', 23, 'doctor', 'doctor', 'module_2', 'health_walker@mars.org'],
            ['Grey', 'Cristine', 23, 'scientist', 'communication network engineer', 'module_3',
             'networks_grey@mars.org'],
            ['Perry', 'Ketty', 18, 'co-pilot', 'spacecraft engineer', 'module_2', 'kperry@mars.org']]
    db_sess = create_session()
    db_sess.add(cap)
    for p in crew:
        user = User()
        user.surname, user.name, user.age, user.position, user.speciality, user.address = p[:-1]
        user.email = p[-1]
        db_sess.add(user)
    db_sess.commit()


def add_jobs():
    jobs = [[1, 'deployment of residential modules 1 and 2', 15, '2, 3', datetime.datetime.now(),
             False],
            [4, 'developing life conditions', 30, '3, 5',
             datetime.datetime(2023, 4, 10, 15, 0, 0, 0), True]]
    db_sess = create_session()
    for j in jobs:
        job = Jobs()
        job.team_leader, job.job, job.work_size, job.collaborators, job.start_date = j[:-1]
        job.is_finished = j[-1]
        db_sess.add(job)
    db_sess.commit()


def add_department():
    deps = [['geology', 3, '3, 4, 5, 6', 'geology_dep@mars.org'],
            ['science only', 3, '3, 5', 'science@mars.org']]
    db_sess = create_session()
    for d in deps:
        dep = Department()
        dep.title, dep.chief, dep.members, dep.email = d
        db_sess.add(dep)
    db_sess.commit()


@app.route('/')
def get_table():
    db_sess = create_session()
    jobs = db_sess.query(Jobs).all()
    team_leaders = db_sess.query(User).filter(User.id.in_(list(map(lambda j: j.team_leader, jobs))))
    return render_template('index.html', jobs=jobs,
                           team_leader=list(map(lambda u: f'{u.name} {u.surname}', team_leaders)),
                           my_style=url_for('static', filename='css/style.css'))


def main():
    global_init('db/new_mars_explorer.db')
    app.run(port=5000, host='127.0.0.1')


if __name__ == '__main__':
    main()
