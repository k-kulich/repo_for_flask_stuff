"""
Cap  login:  scott_chief@mars.org  password: c@p_uNL0cK
Test user  login: test_mail@mars.org  password: mY_nEWp@55

"""
import datetime

from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask import Flask, render_template, url_for, redirect, request, abort
from data.db_session import create_session, global_init
from data.departments import Department
from data.users import User
from data.jobs import Jobs
from forms.loginform import LoginForm
from forms.user import RegisterForm
from forms.dep_add_form import DepForm
from forms.job_add_form import JobForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@login_manager.user_loader
def load_user(user_id):
    db_sess = create_session()
    return db_sess.query(User).get(user_id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/addjob', methods=['GET', 'POST'])
@login_required
def add_job():
    form = JobForm()
    if form.validate_on_submit():
        db_sess = create_session()
        job = Jobs()
        job.team_leader = form.team_leader_id.data
        job.job = form.job.data
        job.work_size = form.work_size.data
        job.collaborators = form.collaborators.data
        job.is_finished = form.is_finished.data
        db_sess.add(job)
        db_sess.commit()
        return redirect('/')
    return render_template('job_add.html', title='Adding a job', form=form)


@app.route('/correctjob/<int:id>', methods=['GET', 'POST'])
@login_required
def correct_job(id):
    form = JobForm()
    if request.method == 'GET':
        db_sess = create_session()
        job = db_sess.query(Jobs).filter(Jobs.id == id).first()
        team_leader = db_sess.query(User).filter(User.id == job.team_leader).first()
        if team_leader and team_leader == current_user or current_user.id == 1:
            form.job.data = job.job
            form.team_leader_id.data = job.team_leader
            form.work_size.data = job.work_size
            form.collaborators.data = job.collaborators
            form.is_finished.data = job.is_finished
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = create_session()
        job = db_sess.query(Jobs).filter(Jobs.id == id).first()
        team_leader = db_sess.query(User).filter(User.id == job.team_leader).first()
        if team_leader and team_leader == current_user or current_user.id == 1:
            job.job = form.job.data
            job.work_size = form.work_size.data
            job.collaborators = form.collaborators.data
            job.is_finished = form.is_finished.data
            db_sess.commit()
            return redirect('/')
        else:
            abort(404)
    return render_template('job_add.html', title='Edit a job', form=form)


@app.route('/deletejob/<int:id>', methods=['GET', 'POST'])
@login_required
def job_delete(id):
    db_sess = create_session()
    job = db_sess.query(Jobs).filter(Jobs.id == id).first()
    team_leader = db_sess.query(User).filter(User.id == job.team_leader).first()
    if team_leader and team_leader == current_user or current_user.id == 1:
        db_sess.delete(job)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/')


@app.route('/')
def get_table():
    db_sess = create_session()
    jobs = db_sess.query(Jobs).all()
    team_leaders = []
    for j in jobs:
        team_leaders.append(db_sess.query(User).filter(User.id == j.team_leader).first())

    return render_template('index.html', title='Work logs', jobs=jobs,
                           team_leader=list(map(lambda u: f'{u.name} {u.surname}', team_leaders)),
                           my_style=url_for('static', filename='css/style.css'))


@app.route('/departments')
def get_dep_table():
    db_sess = create_session()
    deps = db_sess.query(Department).all()
    chiefs = []
    for dep in deps:
        chiefs.append(db_sess.query(User).filter(User.id == dep.chief).first())

    return render_template('departments.html', title='Departments', deps=deps,
                           chiefs=list(map(lambda u: f'{u.name} {u.surname}', chiefs)),
                           my_style=url_for('static', filename='css/style.css'))


@app.route('/add_dep', methods=['GET', 'POST'])
@login_required
def add_dep():
    form = DepForm()
    if form.validate_on_submit():
        db_sess = create_session()
        dep = Department()
        dep.title = form.title.data
        dep.chief = form.chief.data
        dep.members = form.members.data
        dep.email = form.email.data
        db_sess.add(dep)
        db_sess.commit()
        return redirect('/departments')
    return render_template('dep_form.html', title='Adding a job', form=form)


@app.route('/editdep/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_dep(id):
    form = DepForm()
    if request.method == 'GET':
        db_sess = create_session()
        dep = db_sess.query(Department).filter(Department.id == id).first()
        chief = db_sess.query(User).filter(User.id == dep.chief).first()
        if chief and chief == current_user or current_user.id == 1:
            form.title.data = dep.title
            form.chief.data = dep.chief
            form.members.data = dep.members
            form.email.data = dep.email
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = create_session()
        dep = db_sess.query(Department).filter(Department.id == id).first()
        chief = db_sess.query(User).filter(User.id == dep.chief).first()
        if chief and chief == current_user or current_user.id == 1:
            dep.title = form.title.data
            dep.chief = form.chief.data
            dep.members = form.members.data
            dep.email = form.email.data
            db_sess.commit()
            return redirect('/departments')
        else:
            abort(404)
    return render_template('dep_form.html', title='Edit a Department', form=form)


@app.route('/deletedep/<int:id>', methods=['GET', 'POST'])
@login_required
def delete_dep(id):
    db_sess = create_session()
    dep = db_sess.query(Department).filter(Department.id == id).first()
    chief = db_sess.query(User).filter(User.id == dep.chief).first()
    if chief and chief == current_user or current_user.id == 1:
        db_sess.delete(dep)
        db_sess.commit()
    else:
        abort(404)
    return redirect('/departments')


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        user = User()
        user.surname = form.surname.data
        user.name = form.name.data
        user.age = form.age.data
        user.position = form.position.data
        user.speciality = form.speciality.data
        user.address = form.address.data
        user.email = form.email.data
        user.set_password(form.password.data)
        user.modified_date = datetime.datetime.now()
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Register form', form=form)


def main():
    global_init('db/new_mars_explorer.db')
    app.run(port=5000, host='127.0.0.1')


if __name__ == '__main__':
    main()
