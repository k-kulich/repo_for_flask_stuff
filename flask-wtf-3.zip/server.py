import json
from flask import Flask, render_template

app = Flask(__name__)


@app.route('/list_prof/<lst>')
def profs(lst):
    with open("static/text/list_prof.json", "rt", encoding="utf8") as f:
        prof_list = json.loads(f.read())
    return render_template('index.html', profs=prof_list, list=lst)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
