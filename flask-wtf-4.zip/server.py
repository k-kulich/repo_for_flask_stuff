import json
from flask import Flask, render_template, request

app = Flask(__name__)

form_res = {'title': None, 'surname': None, 'name': None, 'education': None,
            'profession': None, 'sex': None, 'motivation': None, 'ready': False}
order = ('title', 'surname', 'name', 'education', 'profession', 'sex', 'motivation', 'ready')


@app.route('/list_prof/<lst>')
def profs(lst):
    with open("static/text/list_prof.json", "rt", encoding="utf8") as f:
        prof_list = json.loads(f.read())
    return render_template('index.html', profs=prof_list, list=lst)


@app.route('/answer')
@app.route('/auto_answer')
def answer():
    return render_template('auto_answer.html', **form_res)


def get_answers():
    for elem in order:
        form_res[elem] = input(f'Enter {elem}:\t\t').strip()
    if form_res['sex'] in {'м', 'муж', 'мужской', 'm', 'male'}:
        form_res['sex'] = 'male'
    else:
        form_res['sex'] = 'female'
    if form_res['ready'].lower() in {'yes', 'yep', 'да', 'д', 'y'}:
        form_res['ready'] = True


if __name__ == '__main__':
    get_answers()
    app.run(port=8080, host='127.0.0.1')
