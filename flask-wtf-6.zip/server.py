import json
from flask import Flask, render_template, redirect
from loginform import MyLoginForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

form_res = {'title': None, 'surname': None, 'name': None, 'education': None,
            'profession': None, 'sex': None, 'motivation': None, 'ready': False}
order = ('title', 'surname', 'name', 'education', 'profession', 'sex', 'motivation', 'ready')

crew = ['Ридли Скотт', 'Энди Уир', 'Марк Уотни', 'Венката Капур', 'Тедди Сандерс', 'Шон Бин']


@app.route('/list_prof/<lst>')
def profs(lst):
    with open("static/text/list_prof.json", "rt", encoding="utf8") as f:
        prof_list = json.loads(f.read())
    return render_template('index.html', profs=prof_list, list=lst)


@app.route('/answer')
@app.route('/auto_answer')
def answer():
    return render_template('auto_answer.html', **form_res)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = MyLoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', title='Аварийный доступ', form=form)


@app.route('/distribution')
def distrib():
    return render_template('distribution.html', title='Каюты', astro_list=crew)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
