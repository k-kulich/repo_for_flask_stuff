from flask import Flask, render_template, url_for

app = Flask(__name__)


@app.route('/training/<prof>')
def instruct(prof):
    img1 = url_for('static', filename='img/ship_ingeneers.png')
    print(img1)
    img2 = url_for('static', filename='img/ship_science.png')
    return render_template('training.html', prof=prof, img1='..' + img1, img2='..' + img2)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
